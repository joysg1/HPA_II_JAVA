import java.util.Scanner;

public class prog_7 {

	public static void main(String[] args) {
	  Scanner data=new Scanner(System.in);
	  int i;
	  int fah;
	  
	  System.out.println("De 5 a -5C a Fahrenheit");
	  for(i=5; i>-6; i--) {
		  
		  fah=i*9/5+32;
		  System.out.println(i +" C = "+fah + " F");
		  
		  
		  
		  
	  }
	  
	  
	  
	}

}
