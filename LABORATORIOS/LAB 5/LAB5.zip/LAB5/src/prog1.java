import java.util.Scanner;
public class prog1 {

	public static void main(String[] args) {
		Scanner data = new Scanner(System.in);
		
		int x=0;
		int sum=0;
		System.out.println("Numeros del 1 al 15:");
		while(x<15){
			
			x=x+1;
			System.out.println(x);
			System.out.println("\n");
			sum =sum +x;
			
			
			
			
			
		}
		System.out.println("Sumatoria de los numeros del 1 al 15:");
		System.out.println(sum);
		
		
		
		
		
		}
	}


