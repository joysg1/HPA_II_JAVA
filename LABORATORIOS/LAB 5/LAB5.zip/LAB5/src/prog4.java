import java.util.Scanner;
public class prog4 {

	public static void main(String[] args) {
		Scanner data = new Scanner(System.in);
		int x=0;
		int a=0;
		int b=0;
		int mayor=0;
		
		while(x<20) {
			x=x+1;
			System.out.println("Ingrese el valor #"+x+":");
			a=data.nextInt();
			System.out.println("\n");
			
			if(a>b)
				mayor=a;
			
			
			
			
			
			
			
			
			
			
			
			
		b=a;	
			
		}
		System.out.println("El numero mayor es " +mayor);
		
		
		

	}

}
