
public class prog_2 {

	public static void main(String[] args) {
		int a[]= new int [101];
		
		int i;
		for(i=0; i<101; i++) {
			a[i]=i;
			
			
			
		}
		
		par(a);
		
		
		
		
		
		
		
		
	
	}
	
	public static void par(int b[]) {
		int i;
		
		for(i=0; i<101; i++) {
			if (b[i]%2==0 && b[i]!=0)
			 System.out.println(b[i]);
			
			
			
			
			
			
		}
		
		
		
		
		
	}
	
	
	
	
	
	
	

}
