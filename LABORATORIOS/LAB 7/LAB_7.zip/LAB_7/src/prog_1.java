import java.util.Arrays;
import java.util.Collections;
public class prog_1 {

	public static void main(String[] args) {
		
		Integer a[]= new Integer[101];
		int i;
		
		for(i=0; i<101; i++) {
			a[i]=i;
			
			
			
		}
		
		Arrays.sort(a,Collections.reverseOrder());
		for(int n:a) {
			
			System.out.println(n);
		}
		
		
     
	}
	
	
	
	
		
		
		
		
		
		
	}
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	


